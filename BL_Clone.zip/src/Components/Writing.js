import React from "react";

const Writing = () => {
  return <div>Writing</div>;
};

export default Writing;
